// Богачев, страница 143

#include <sys/time.h>
#include <sys/resource.h>
#include "get_time.h"

// Вернуть процессорное время, затраченное на данный процесс, в сотых долях секунды
// Берется время только самого процесса, время работы системных вызовов не прибавляется
long int get_time() {
	struct rusage buf;
	
	getrusage (RUSAGE_SELF, &buf);
	return buf.ru_utime.tv_sec * 100 + buf.ru_utime.tv_usec / 10000;
}

// Возвращает астрономическое время в сотых долях секунды
/*long int get_full_time() {
	struct timeval buf;
	
	gettimeofday (&buf, 0);
	return buf.tv_sec * 100 + buf.tv_usec / 10000 ;
}	
*/

// с семинара
double get_full_time() {
	struct timeval tm;
	
	gettimeofday(&tm, 0);
	
	//return tm.tv_sec + (tm.tv_usec)/1000000.0;
	return tm.tv_sec + (tm.tv_usec)/1000000.;
}
