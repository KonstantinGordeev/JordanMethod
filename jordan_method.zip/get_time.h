#ifndef GET_TIME_H
#define GET_TIME_H
long int get_time();
double get_full_time();
#endif
